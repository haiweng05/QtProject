#ifndef SCHEDULE_H
#define SCHEDULE_H

#include<vector>
#include<QString>
#include<unordered_map>
#include<set>
#include<vector>
#include"event.h"

class schedule{
public:
    std::vector<Event> week[8];

};

#endif // SCHEDULE_H
